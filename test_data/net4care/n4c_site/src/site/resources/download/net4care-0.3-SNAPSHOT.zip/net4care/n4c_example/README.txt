This folder contains some examples of progressing complexity 
that demonstrate most of the features of the Net4Care Ecosystem
framework.

The simplest one is HelloWorld and a good starting point.

All examples are explained on the web site www.net4care.org.

Have Fun...

The Net4Care team...